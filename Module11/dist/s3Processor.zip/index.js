const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const ddb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event));
  for (const record of event.Records || []) {
    const bucket = record.s3.bucket.name;
    const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '));
    try {
      const obj = await s3.getObject({ Bucket: bucket, Key: key }).promise();
      const body = obj.Body.toString('utf-8');
      const item = {
        id: key,
        content: body,
        timestamp: new Date().toISOString()
      };
      await ddb.put({ TableName: process.env.TABLE_NAME, Item: item }).promise();
      console.log('Saved item', item.id);
    } catch (err) {
      console.error('Error processing record', err);
      throw err;
    }
  }
  return { statusCode: 200 };
};
